role_name = "Data Scientist"
url_list = ['https://storage.googleapis.com/msds692-hw1-public/job_list.pkl']
company_dictionary = {"Meta": "https://www.metacareers.com/jobs",
                      "Google": "https://www.google.com/about/"
                      "careers/applications/jobs"}
